import 'package:delevery_app/model/catagorymodel.dart';


List<Categorymodel> getCategories(){

  List<Categorymodel> category=[];
    Categorymodel  categorymodel= new Categorymodel();

    categorymodel.name="Pizza";
    //add piza image// like images/piza.png
    categorymodel.images='';
    category.add(categorymodel);
    categorymodel = new Categorymodel();
  

  /// same for burger 
  /// note add image
  categorymodel.name="Burger";

    categorymodel.images='';
    category.add(categorymodel);
    categorymodel = new Categorymodel();

    // chines
    categorymodel.name="Chines";
    categorymodel.images='';
    category.add(categorymodel);
    categorymodel = new Categorymodel();

    //tacos
    categorymodel.name='Tacos';
    categorymodel.images='';
    category.add(categorymodel);
    categorymodel =new Categorymodel();
  
  return category;
}