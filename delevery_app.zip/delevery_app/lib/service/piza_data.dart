import 'package:delevery_app/model/pizamodel.dart';
import 'package:flutter/material.dart';

List<PizzaModel> getPizza(){
  List<PizzaModel>pizza=[];
  PizzaModel pizzaModel = new Pizamodel();
   
   pizzaModel.name='pizza 1';
   pizzaModel.image='images/pizza image add';
   pizza.add(pizzaModel);
   pizzaModel =new Pizamodel();

   pizzaModel.name='pizza 2';
   pizzaModel.image='images/pizza image add';
   pizza.add(pizzaModel);
   pizzaModel =new Pizamodel();


   return  pizza;


}

