import 'package:flutter/material.dart';


class AppWidget{
  static TextStyle HeadingStyle(){

    return TextStyle(
      color: Colors.black, fontSize: 25.0, fontWeight: FontWeight.bold
    );
    
  }

  static TextStyle SimpleStyle(){
    return TextStyle(
      color: Colors.black, fontSize: 20, 
    );
  }
}

  
