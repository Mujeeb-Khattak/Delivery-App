import 'dart:ffi';

import 'package:delevery_app/service/catagorydata.dart';
import 'package:delevery_app/service/widget_support.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}


class _HomeState extends State<Home> {
  List<Categorymodel> Categories=[];



  @override
  Void initState(){
    categories=getCategories();
    super.initState();
  }

  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Column(
          children: [
            Column(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [ 
                    //logo
                    
                    Image.asset('images/del1.webp'),
                    Text('Order Your Favorate ', style: AppWidget.SimpleStyle(),)],
                           
                ),

                //USER images
                Padding(
                  padding: const EdgeInsets.only(left: 20),
                  child: ClipRRect
                  
                  (
                    borderRadius: BorderRadius.circular(10),
                    child: 
                                Image.asset('images/del1.webp', height: 20,width: 20,fit: BoxFit.cover,)),
                )
              ],
            ),
            SizedBox(
              height: 10,
            ),


            Row(
              children: [
                Expanded(
                  child: Container(
                    margin: EdgeInsets.only(right: 20),
                    decoration: BoxDecoration(color: Colors.white, 
                    borderRadius: BorderRadius.circular(10),),
                    
                    
                  
                    child: TextField(
                  
                    decoration:InputDecoration(
                      border: InputBorder.none,
                      hintText: 'Search  food item'
                    ) ,
                    
                    ),
                    
                  ),
                ),
                Container(
                  padding: EdgeInsets.all(5),
                  margin: EdgeInsets.only(right: 10),
                  decoration: BoxDecoration(
                    color: Colors.red,
                    borderRadius: BorderRadius.circular(10)
                  
                  ),
                  child: Icon(Icons.search, color: Colors.white,
                  size: 30,),
                )
              ],
            ),
            SizedBox(
              height: 20,
              width: 20,
            ),

            Container(
              height: 80,
              child: ListView.builder(
                shrinkWrap: true,
                scrollDirection: Axis.horizontal,
                itemCount: Categories.length,
                
                itemBuilder: (context, index){
                  return CategoryTile(
                    image: Categories[index].image!,
                    name: Categories[index].name!, categoriesindex: index.toString(),
              
                  );
                }),
            )
           
          ],
        ),
      ),
    );
  }
}
class CategoryTile extends StatefulWidget {
  
  String name, image, categoriesindex;
  CategoryTile({
    required this.name, required this.image , required this.categoriesindex
  });

  @override
  State<CategoryTile> createState() => _CategoryTileState();
}

class _CategoryTileState extends State<CategoryTile> {
  @override
  Widget build(BuildContext context) {
    String track="0";
    return  GestureDetector(
      onTap: (){
        track=widget.categoriesindex.toString();
        setState(() {
          
        });
      },
      child:  track==widget.categoriesindex? Container(
        padding: EdgeInsets.only(left: 10,right: 10),
        margin: EdgeInsets.only(right: 20.0),
        decoration: BoxDecoration(
          color: Colors.red,
          borderRadius: BorderRadius.circular(10)
      
        ),
        child: Row(
          children: [
            Image.asset(widget.image, height: 50, width: 50,
            fit: BoxFit.cover),
            Text(widget.name , style: AppWidget.whiteSimpleStyle(),)
          ],
        ),
        
      ):Container(
        margin: EdgeInsets.only(right: 20.0),
        padding: EdgeInsets.only(left: 20, right: 20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Color(0xFFececf8),

        
        ),
        child: Row(
          children: [
            Image.asset(widget.image, height: 50, width: 50,
            fit: BoxFit.cover),
            Text(widget.name , style: AppWidget.SimpleStyle(),)
          ],
          

        ),
      )

      );
    
    

  }
}