import 'package:delevery_app/service/widget_support.dart';
import 'package:flutter/material.dart';

class Onborading extends StatefulWidget {
  const Onborading({super.key});

  @override
  State<Onborading> createState() => _OnboradingState();
}

class _OnboradingState extends State<Onborading> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:Colors.white,
      body: Container(
        
        margin: EdgeInsets.only(top: 20),
        child: Column(
          
      
          children: [
            
            SizedBox(
              
              height: 500,
              width: 500,
              child: Image.asset('images/del1.webp', fit: BoxFit.cover,),
            ),
            // Image.asset('images/del1.webp', fit: BoxFit.fill,),
            Text('Khattat Fastest\n Delivery',
            textAlign:TextAlign.center,
             style: AppWidget.HeadingStyle(),),
             Text('Bridging distances,\n one delivery at a time!', style: AppWidget.SimpleStyle(),),
             SizedBox(
              height: 20,
              width: 20,
             ),
             Container(
              height: 50,
              
              width: MediaQuery.of(context).size.width /2,
              decoration: BoxDecoration(
                color: Colors.amber,
                
              ),
              child: Center(
                child: Text('Get Started ', style: TextStyle(
                  color: Colors.white, 
                  fontSize: 20.0,
                  fontWeight: FontWeight.bold
                ),),
              ),
             )
          ],
          
        ),
      ),
    );
  }
}